# جدول الشرطه العام Elite RP

A Pen created on CodePen.

Original URL: [https://codepen.io/Hussain-Alqahtani/pen/LEbQPeb](https://codepen.io/Hussain-Alqahtani/pen/LEbQPeb).

